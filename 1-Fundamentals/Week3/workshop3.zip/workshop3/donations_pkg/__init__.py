"""
__init__.py file for donation app on Week3 Workshop3
"""